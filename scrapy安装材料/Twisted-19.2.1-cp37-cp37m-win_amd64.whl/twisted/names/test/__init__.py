"Tests for twisted.names"
